# -*- coding: utf-8 -*-

from datamate.core.base_op import OPERATORS

OPERATORS.register_module(module_name='TestMapper',
                          module_path="ops.user.test_operator.process")
